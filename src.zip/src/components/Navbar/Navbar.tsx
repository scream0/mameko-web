// @ts-nocheck
"use client";
import { useState, useRef, useEffect, useMemo } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { usePathname } from "next/navigation";
import { useStore } from "@/context/StoreContext";
import { useTheme } from "@/context/ThemeContext";
import { SearchForm } from "./SearchForm";
import styles from "./Navbar.module.css";
import config from "@/data/ui/navbarConfig.json";
import { Logo } from "@/components/UI/Logo/logo";
import { AppIcon } from "@/components/UI/Icon/AppIcon";
import { useScrollLock } from "@/hooks/useScrollLock";
import { optimizeCloudinaryUrl, IMAGE_PRESETS } from "@/utils/imageOptimizer";

const CartSidebar = dynamic(
  () => import("../UI/Sidebar/CartSidebar").then((mod) => mod.CartSidebar),
  { ssr: false }
);

const Modal = dynamic(
  () => import("../UI/Modal/ProductModal").then((mod) => mod.Modal),
  { ssr: false }
);

export function Navbar() {
  const [activePanel, setActivePanel] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [animate, setAnimate] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [isClient, setIsClient] = useState(false);
  const [activeHash, setActiveHash] = useState("");
  const [hoverStyle, setHoverStyle] = useState({});
  const [hoveredLink, setHoveredLink] = useState(null);

  const {
    products,
    addToCart,
    rupiah,
    cartQuantity,
    user,
    logout,
    isCartOpen,
    setIsCartOpen,
  } = useStore();

  const { isThemeReady } = useTheme();
  const pathname = usePathname();

  const authItems = config?.authSection?.auth?.authenticated || [];
  const unauthItem = config?.authSection?.auth?.unauthenticated?.[0];

  const userMenuRef = useRef(null);

  useScrollLock(
    activePanel === "navbar" || activePanel === "search" || isCartOpen
  );

  useEffect(() => {
    let rafId = null;
    const handleScroll = () => {
      if (rafId) return; // sudah ada frame pending, skip
      rafId = requestAnimationFrame(() => {
        setIsScrolled(window.scrollY > 50);
        rafId = null;
      });
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (rafId) cancelAnimationFrame(rafId);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    setIsClient(true);
  }, []);

  useEffect(() => {
    if (cartQuantity > 0) {
      setAnimate(true);
      const timer = setTimeout(() => setAnimate(false), 600);
      return () => clearTimeout(timer);
    }
  }, [cartQuantity]);

  // Tutup dropdown/panel yang lagi terbuka pas user pencet Escape
  useEffect(() => {
    const handleKeyDown = (event: any) => {
      if (event.key !== "Escape") return;
      if (isUserMenuOpen) setIsUserMenuOpen(false);
      if (activePanel) setActivePanel(null);
      if (isCartOpen) setIsCartOpen(false);
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isUserMenuOpen, activePanel, isCartOpen, setIsCartOpen]);

  // Lacak hash aktif di URL (buat active link indicator pada anchor menu)
  useEffect(() => {
    const updateHash = () => setActiveHash(window.location.hash);
    updateHash();
    window.addEventListener("hashchange", updateHash);
    return () => window.removeEventListener("hashchange", updateHash);
  }, []);

// Handler navigasi cerdas untuk Anchor Link / Hash (#)
  const handleNavClick = (e, href: any) => {
    setActivePanel(null);

    if (href && href.includes("#")) {
      e.preventDefault();

      // Ambil bagian hash-nya saja (contoh: "product" dari "/#product" atau "#product")
      const hashPart = href.split("#")[1];
      const isHome = window.location.pathname === "/";

      if (isHome) {
        // Cari elemen berdasarkan ID section produk Anda
        const targetElement = document.getElementById(hashPart) || document.querySelector(`#${hashPart}`);

        if (targetElement) {
          targetElement.scrollIntoView({ behavior: "smooth", block: "start" });
          // Perbarui URL hash di browser tanpa memuat ulang halaman
          window.history.pushState(null, "", `#${hashPart}`);
          setActiveHash(`#${hashPart}`);
        } else {
          // Fallback jika elemen belum terpanggil
          window.location.hash = hashPart;
        }
      } else {
        // Jika sedang berada di halaman lain, arahkan kembali ke beranda beserta hash-nya
        window.location.href = `/#${hashPart}`;
      }
    }
  };

  // Cek apakah sebuah menu item sedang "aktif" (match pathname penuh, atau match hash)
  const isLinkActive = (href: any) => {
    if (!href) return false;
    if (href.includes("#")) {
      const hashPart = href.split("#")[1];
      return activeHash === `#${hashPart}`;
    }
    return pathname === href;
  };

  const productList = Array.isArray(products) ? products : products?.data || [];

  // Cuma dihitung ulang kalau produk/queries berubah, dan cuma kalau panel search
  // sedang aktif — hindari filter jalan sia-sia tiap render (scroll, toggle theme, dll).
  const filtered = useMemo(() => {
    if (activePanel !== "search") return [];
    return productList.filter((p: any) =>
      p?.name?.toLowerCase().includes(searchQuery.toLowerCase()),
    );
  }, [productList, searchQuery, activePanel]);

  const togglePanel = (panelName: any) => {
    setActivePanel((prev) => (prev === panelName ? null : panelName));
    setIsCartOpen(false); // pastikan cart nggak numpuk sama panel lain
  };

  const handleToggleCart = () => {
    setIsCartOpen((prev: any) => !prev);
    setActivePanel(null); // pastikan panel lain nggak numpuk sama cart
  };

  const handleMouseEnter = (e, index: any) => {
    const el = e.currentTarget;
    setHoverStyle({
      width: el.offsetWidth,
      left: el.offsetLeft,
      opacity: 1,
    });
    setHoveredLink(index);
  };

  const handleMouseLeave = () => {
    setHoverStyle((prev) => ({ ...prev, opacity: 0 }));
    setHoveredLink(null);
  };

  const userAvatar = user?.photoURL || user?.photo_url;
  const userName =
    user?.full_name ||
    user?.username ||
    user?.displayName ||
    user?.email?.split("@")[0] ||
    "User";

  return (
    <>
      <nav className={`${styles.navbar} ${isScrolled ? styles.scrolled : ""}`}>
        <Link href={config.logo.href} className={styles.logo}>
          <Logo className={styles.logoSvg} />
          {config.logo.text}
          <span>{config.logo.subtext}</span>.
        </Link>

        <div
          className={`${styles.navbarNav} ${activePanel === "navbar" ? styles.active : ""}`}
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setActivePanel(null);
            }
          }}
          onMouseLeave={handleMouseLeave}
        >
          <div
            className={styles.mobileDrawerPane}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header Drawer Khusus Mobile (Logo + Tombol Close) */}
            <div className={styles.mobileDrawerHeader}>
              <Link
                href={config.logo.href}
                className={styles.mobileDrawerLogo}
                onClick={() => setActivePanel(null)}
              >
                <Logo className={styles.mobileLogoSvg} />
                {config.logo.text}
                <span>{config.logo.subtext}</span>.
              </Link>
              <button
                className={styles.mobileCloseBtn}
                onClick={() => setActivePanel(null)}
                aria-label={config?.features?.mobileDrawer?.closeAriaLabel || "Tutup Menu Navigasi"}
              >
                <AppIcon
                  name={config?.features?.mobileDrawer?.iconClose || "x"}
                  className={styles.closeIconSvg}
                />
              </button>
            </div>

            <div className={styles.navHoverPill} style={hoverStyle} />

            <div className={styles.mobileNavList}>
              {config.menuItems.map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  onMouseEnter={(e) => handleMouseEnter(e, index)}
                  className={`${styles.mobileNavLink} ${isLinkActive(item.href) ? styles.navLinkActive : ""}`}
                  aria-current={isLinkActive(item.href) ? "page" : undefined}
                >
                  <span>{item.label}</span>
                  <span className={styles.navLinkArrow}>
                    <AppIcon
                      name={config?.features?.mobileDrawer?.navLinkIcon || "chevron-right"}
                      className={styles.arrowIconSvg}
                    />
                  </span>
                </Link>
              ))}
            </div>

            <div className={styles.mobileAuthSection}>
              {user ? (
                <>
                  <div className={styles.mobileUserInfo}>
                    {userAvatar && !imageError ? (
                      <img
                        src={optimizeCloudinaryUrl(userAvatar, IMAGE_PRESETS.THUMBNAIL_SM)}
                        alt="User Avatar"
                        className={styles.avatarImgMobile}
                        onError={() => setImageError(true)}
                      />
                    ) : (
                      <div className={styles.avatarPlaceholderMobile}>
                        <AppIcon name="user" className={styles.svgIcon} />
                      </div>
                    )}
                    <span className={styles.mobileUserName}>{userName}</span>
                  </div>
                  {authItems.map((item, index) =>
                    item.type === "link" ? (
                      <Link
                        key={index}
                        href={item.href}
                        className={styles.mobileAuthLink}
                        onClick={() => setActivePanel(null)}
                      >
                        {item.label}
                      </Link>
                    ) : (
                      <button
                        key={index}
                        onClick={() => {
                          logout();
                          setActivePanel(null);
                        }}
                        className={`${styles.mobileAuthLink} ${styles.mobileLogoutBtn}`}
                      >
                        {item.label}
                      </button>
                    ),
                  )}
                </>
              ) : (
                unauthItem && (
                  <Link
                    href={unauthItem.href}
                    className={styles.mobileLoginBtn}
                    onClick={() => setActivePanel(null)}
                  >
                    {unauthItem.label}
                  </Link>
                )
              )}
            </div>
          </div>
        </div>

        <SearchForm
          isActive={activePanel === "search"}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          filteredProdukItems={filtered}
          rupiah={rupiah}
          onResultClick={(item: any) => {
            setSelectedProduct(item);
            setIsModalOpen(true);
            setActivePanel(null);
            setSearchQuery("");
          }}
        />


        <div className={styles.navbarExtra}>
          <button
            onClick={() => togglePanel("search")}
            aria-label="Cari Produk"
          >
            <AppIcon name={config?.features?.search?.icon} className={styles.svgIcon} />
          </button>

          <button
            className={styles.cartButton}
            onClick={handleToggleCart}
            aria-label={config?.features?.cart?.ariaLabel}
          >
            <AppIcon
              name={config?.features?.cart?.icon}
              className={`${styles.svgIcon} ${animate ? styles.cartBounce : ""}`}
            />
            {isClient && cartQuantity > 0 && (
              <span
                className={`${styles.quantityBadge} ${animate ? styles.quantityPulse : ""}`}
              >
                {cartQuantity}
                {animate && (
                  <span className={styles.pulseRing} aria-hidden="true" />
                )}
              </span>
            )}
          </button>



          <div className={styles.authContainer}>
            {user ? (
              <div className={styles.userMenu} ref={userMenuRef}>
                <button
                  className={styles.userAvatarBtn}
                  onClick={() => setIsUserMenuOpen((prev) => !prev)}
                  aria-label="Menu Pengguna"
                >
                  {userAvatar && !imageError ? (
                    <img
                      src={optimizeCloudinaryUrl(userAvatar, IMAGE_PRESETS.THUMBNAIL_SM)}
                      alt="User Avatar"
                      className={styles.avatarImg}
                      onError={() => setImageError(true)}
                    />
                  ) : (
                    <AppIcon name="user" className={styles.svgIcon} />
                  )}
                </button>
                {isUserMenuOpen && (
                  <div className={styles.userDropdown}>
                    <div className={styles.dropdownHeader}>
                      <span className={styles.dropdownUserName}>
                        {userName}
                      </span>
                      <span className={styles.dropdownUserEmail}>
                        {user.email}
                      </span>
                    </div>
                    {authItems.map((item, index) =>
                      item.type === "link" ? (
                        <Link
                          key={index}
                          href={item.href}
                          className={styles.dropdownItem}
                          onClick={() => setIsUserMenuOpen(false)}
                        >
                          {item.label}
                        </Link>
                      ) : (
                        <button
                          key={index}
                          onClick={() => {
                            logout();
                            setIsUserMenuOpen(false);
                          }}
                          className={`${styles.dropdownItem} ${styles.logoutBtn}`}
                        >
                          {item.label}
                        </button>
                      ),
                    )}
                  </div>
                )}
              </div>
            ) : (
              unauthItem && (
                <Link href={unauthItem.href} className={styles.loginBtn}>
                  {unauthItem.label}
                </Link>
              )
            )}
          </div>

          <button
            onClick={() => togglePanel("navbar")}
            className={styles.hamburger}
            aria-label="Menu Navigasi"
          >
            <AppIcon
              name={activePanel === "navbar" ? config?.features?.hamburger?.iconClose : config?.features?.hamburger?.iconOpen}
              className={styles.svgIcon}
            />
          </button>
        </div>
      </nav>

      {isCartOpen && <CartSidebar />}

      {isModalOpen && selectedProduct && (
        <Modal
          isOpen={isModalOpen}
          item={selectedProduct}
          rupiah={rupiah}
          onClose={() => setIsModalOpen(false)}
          onAddToCart={(product, variant: any, quantity: any) => {
            addToCart(product, variant, quantity);
            setIsModalOpen(false);
          }}
        />
      )}
    </>
  );
}