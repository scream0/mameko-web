// @ts-nocheck
"use client";
import { useEffect } from "react";

export function useOutsideClick(ref, handler) {
  useEffect(() => {
    const listener = (event) => {
      // Jika ref tidak ada atau klik terjadi di dalam elemen, abaikan
      if (!ref.current || ref.current.contains(event.target)) {
        return;
      }
      handler(event);
    };

    // Tambahkan mousedown DAN touchstart untuk dukungan mobile
    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);

    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, handler]);
}
