"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { useStore } from "@/context/StoreContext";
import Shop from '@/components/Dashboard/User/Shop/Shop';
import { supabase } from "@/lib/supabaseClient";
import type { InitialDataType, Product } from '@/types/data'; // Import shared types

const Modal = dynamic(() => import("@/components/UI/Modal/ProductModal").then((mod) => mod.Modal), {
  ssr: false,
});

// The `ProductLike` type can still be useful here for props that accept a product-like object.
type ProductLike = Product & {
  [key: string]: unknown;
};

const Contact = dynamic(() => import('@/components/Contact/Contact').then(mod => mod.Contact), {
  loading: () => <p>Loading Contact Form...</p>, // Optional loading component
  ssr: false, // This is allowed in a Client Component
});

// This component contains the client-side logic for the shop and product modal.
export function HomePageClient({ initialData }: { initialData: InitialDataType }) {
  const [selectedProduct, setSelectedProduct] = useState<ProductLike | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { addToCart, rupiah } = useStore();

  // Supabase Realtime listener untuk store_config di landing page
  useEffect(() => {
    const channel = supabase
      .channel("landing-store-config-sync")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "store_config" },
        () => {
          if (typeof window !== "undefined") {
            window.dispatchEvent(new CustomEvent("store-settings-updated"));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const bukaDetail = (item: ProductLike) => {
    setSelectedProduct(item);
    setIsModalOpen(true);
  };

  return (
    <div>
      <div id="product">
        <Shop onBukaDetail={bukaDetail} initialData={initialData} />
      </div>

      {/* Modal Detail Produk */}
      {isModalOpen && selectedProduct && (
        <Modal
          isOpen={isModalOpen}
          item={selectedProduct}
          onClose={() => setIsModalOpen(false)}
          onAddToCart={addToCart}
          rupiah={rupiah}
        />
      )}

      <Contact />
    </div>
  );
}
